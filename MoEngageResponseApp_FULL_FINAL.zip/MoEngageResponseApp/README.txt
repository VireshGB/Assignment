
MoEngage Response Code Project - Java (J2EE, JSP, Servlets, MySQL, JDBC)
------------------------------------------------------------------------

Includes:
- login.jsp, signup.jsp
- search.jsp with filter (e.g. 2xx, 20x, 203)
- Servlets: LoginServlet, SignupServlet, SearchServlet
- DAO: UserDAO
- SQL schema file: moengage_db.sql

How to Use:
1. Import project in Eclipse as Dynamic Web Project.
2. Add MySQL Connector JAR to build path.
3. Run on Apache Tomcat.
4. Import SQL to create database + tables.

Video demo should show:
- Signup/Login
- Filter + search
- Saved list display

For more, add: SaveListServlet, ListServlet, ViewListServlet
