
package com.moengage.app.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

public class SearchServlet extends HttpServlet {
    private static final List<String> VALID_CODES = List.of(
        "100", "101", "200", "201", "202", "203", "204", "205", "206",
        "300", "301", "302", "303", "304", "307", "308",
        "400", "401", "403", "404", "405", "406", "408", "409", "410",
        "500", "501", "502", "503", "504", "505"
    );

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String filter = request.getParameter("filter").toLowerCase().replaceAll("\s", "");
        List<String> matched = new ArrayList<>();

        for (String code : VALID_CODES) {
            if (matches(filter, code)) {
                matched.add("https://http.dog/" + code + ".jpg");
            }
        }

        request.setAttribute("results", matched);
        request.setAttribute("filter", filter);
        request.getRequestDispatcher("search.jsp").forward(request, response);
    }

    private boolean matches(String filter, String code) {
        if (filter.contains("x")) {
            String regex = filter.replace("x", "\\d");
            return code.matches(regex);
        } else {
            return code.equals(filter);
        }
    }
}
