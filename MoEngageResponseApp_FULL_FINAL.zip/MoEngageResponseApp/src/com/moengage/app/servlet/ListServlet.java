
package com.moengage.app.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class ListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = (String) request.getSession().getAttribute("user");
        List<String> imageList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moengage_db", "root", "yourpassword");

            String sql = "SELECT rc.image_url FROM users u " +
                         "JOIN response_lists rl ON u.id = rl.user_id " +
                         "JOIN response_codes rc ON rl.id = rc.list_id " +
                         "WHERE u.email = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                imageList.add(rs.getString("image_url"));
            }

            request.setAttribute("images", imageList);
            request.getRequestDispatcher("lists.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
