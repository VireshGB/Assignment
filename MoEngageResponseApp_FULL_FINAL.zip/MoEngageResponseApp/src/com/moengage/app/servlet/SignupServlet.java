
package com.moengage.app.servlet;

import com.moengage.app.dao.UserDAO;
import com.moengage.app.model.User;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/moengage_db", "root", "yourpassword"
            );
            UserDAO dao = new UserDAO(conn);
            if (dao.registerUser(user)) {
                response.sendRedirect("login.jsp?success=registered");
            } else {
                response.sendRedirect("signup.jsp?error=exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
