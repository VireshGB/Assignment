
package com.moengage.app.servlet;

import com.moengage.app.dao.UserDAO;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/moengage_db", "root", "yourpassword"
            );
            UserDAO dao = new UserDAO(conn);
            if (dao.validateUser(email, password)) {
                HttpSession session = request.getSession();
                session.setAttribute("user", email);
                response.sendRedirect("search.jsp");
            } else {
                response.sendRedirect("login.jsp?error=invalid");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
