
package com.moengage.app.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.Date;

public class SaveListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String listName = request.getParameter("listName");
        String[] imageLinks = request.getParameterValues("images");
        String email = (String) request.getSession().getAttribute("user");

        if (email == null || listName == null || imageLinks == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moengage_db", "root", "yourpassword");

            String userQuery = "SELECT id FROM users WHERE email = ?";
            PreparedStatement psUser = conn.prepareStatement(userQuery);
            psUser.setString(1, email);
            ResultSet rs = psUser.executeQuery();

            if (!rs.next()) return;

            int userId = rs.getInt("id");

            String listInsert = "INSERT INTO response_lists (user_id, list_name, creation_date) VALUES (?, ?, ?)";
            PreparedStatement psList = conn.prepareStatement(listInsert, Statement.RETURN_GENERATED_KEYS);
            psList.setInt(1, userId);
            psList.setString(2, listName);
            psList.setDate(3, new java.sql.Date(new Date().getTime()));
            psList.executeUpdate();

            ResultSet listKeys = psList.getGeneratedKeys();
            if (!listKeys.next()) return;
            int listId = listKeys.getInt(1);

            String insertCode = "INSERT INTO response_codes (list_id, code, image_url) VALUES (?, ?, ?)";
            PreparedStatement psCode = conn.prepareStatement(insertCode);

            for (String url : imageLinks) {
                String code = url.replaceAll("https://http.dog/|.jpg", "");
                psCode.setInt(1, listId);
                psCode.setString(2, code);
                psCode.setString(3, url);
                psCode.addBatch();
            }

            psCode.executeBatch();
            response.sendRedirect("lists.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
